# Data for this project: transaction-level "what was bought together"
# retail data.
#
# OPTION A (real data): "Online Retail II" (UCI / Kaggle) -- the same
#   dataset used in the sales-analytics-dashboard project. Download the
#   XLSX and place it at data/raw/online_retail_II.xlsx. We reuse it
#   here for a completely different technique: association rule mining
#   instead of RFM segmentation.
#     https://archive.ics.uci.edu/dataset/502/online+retail+ii
#
# OPTION B (runs immediately, no download): simulated grocery-style
#   transactions with realistic item associations baked in (e.g. diapers
#   + beer, pasta + pasta sauce, chips + salsa), so there's something
#   genuine for the algorithm to discover.
#   Run R/00_simulate_data.R.
#
# Either way, label clearly in your report whether results are from
# real or simulated data.

message("Use Option A (download Online Retail II) or Option B (source('R/00_simulate_data.R')).")
