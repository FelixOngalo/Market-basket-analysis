# Simulate 8,000 grocery-store transactions (baskets) with realistic,
# deliberately engineered item associations, so market basket analysis
# has real patterns to recover -- useful for learning the method
# correctly before applying it to messier real data.

library(dplyr)
library(purrr)
library(readr)

set.seed(99)

n_transactions <- 8000

# The full item catalog, grouped loosely by aisle -- this grouping isn't
# used by the algorithm, it's just to make the item list readable.
catalog <- c(
  # Breakfast
  "cereal", "milk", "orange_juice", "bread", "eggs", "butter",
  # Snacks (associated pair: chips + salsa)
  "tortilla_chips", "salsa", "soda", "candy",
  # Pasta night (associated pair: pasta + pasta_sauce + parmesan)
  "pasta", "pasta_sauce", "parmesan", "garlic_bread",
  # Baby + beer (the classic, possibly apocryphal retail anecdote --
  # included deliberately as the textbook example)
  "diapers", "beer", "baby_wipes", "formula",
  # Produce
  "bananas", "apples", "lettuce", "tomatoes", "onions",
  # Household (mostly independent/noise items)
  "paper_towels", "dish_soap", "trash_bags", "batteries"
)

# Deliberately engineered association rules: each entry is a set of
# items that, when present, boost the chance of a related item also
# being in the basket. This is what the apriori algorithm should
# rediscover later -- the "ground truth" for this simulated dataset.
boost_rules <- list(
  list(trigger = "tortilla_chips", boosted = "salsa",       p = 0.65),
  list(trigger = "pasta",          boosted = "pasta_sauce",  p = 0.70),
  list(trigger = "pasta_sauce",    boosted = "parmesan",     p = 0.45),
  list(trigger = "diapers",        boosted = "beer",         p = 0.35),   # the textbook case
  list(trigger = "diapers",        boosted = "baby_wipes",   p = 0.60),
  list(trigger = "cereal",         boosted = "milk",         p = 0.55),
  list(trigger = "bread",          boosted = "butter",       p = 0.40)
)

simulate_basket <- function() {
  # Base: each item has a small independent chance of being picked up,
  # so baskets aren't ONLY the engineered pairs.
  base_probs <- setNames(runif(length(catalog), 0.03, 0.12), catalog)
  items <- names(base_probs)[runif(length(catalog)) < base_probs]

  # Apply the boost rules: if the trigger item is present, give the
  # boosted item its (much higher) conditional probability.
  for (rule in boost_rules) {
    if (rule$trigger %in% items && !(rule$boosted %in% items)) {
      if (runif(1) < rule$p) items <- c(items, rule$boosted)
    }
  }

  # Every basket has at least one item
  if (length(items) == 0) items <- sample(catalog, 1)
  items
}

transactions <- map(seq_len(n_transactions), ~ simulate_basket())

long_format <- map_dfr(seq_along(transactions), function(i) {
  tibble(transaction_id = i, item = transactions[[i]])
})

dir.create("data/raw", showWarnings = FALSE, recursive = TRUE)
write_csv(long_format, "data/raw/transactions_long.csv")
message("Simulated ", n_transactions, " transactions, ", nrow(long_format), " item lines.")
message("Engineered associations (ground truth to check the algorithm against):")
walk(boost_rules, ~ message("  ", .x$trigger, " -> ", .x$boosted, " (p=", .x$p, ")"))
