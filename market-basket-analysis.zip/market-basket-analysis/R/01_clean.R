library(readr)
source("R/cleaning.R")

raw   <- read_csv("data/raw/transactions_long.csv", show_col_types = FALSE)
clean <- clean_transactions_long(raw)

cat("Transactions:", n_distinct(clean$transaction_id), "\n")
cat("Unique items:", n_distinct(clean$item), "\n")
cat("Item lines:  ", nrow(clean), "\n")
cat("Avg basket size:", round(nrow(clean) / n_distinct(clean$transaction_id), 2), "items\n")

saveRDS(clean, "data/clean/transactions_clean.rds")
