library(dplyr)
source("R/basket_functions.R")

clean <- readRDS("data/clean/transactions_clean.rds")
trans <- to_transactions(clean)

cat("=== Transaction summary ===\n")
print(trans)
cat("\n")

# Item frequency: how often each item appears across all baskets --
# always look at this BEFORE mining rules, since an item that's in
# almost every basket (or almost no baskets) will dominate or vanish
# from the rule set in ways that are easy to misread without context.
item_freq <- itemFrequency(trans, type = "relative") |>
  sort(decreasing = TRUE)
print(round(head(item_freq, 10), 3))

# Mine rules at a moderate threshold first
rules <- run_apriori(trans, min_support = 0.01, min_confidence = 0.3, min_lift = 1.0)
cat("\nRules found:", length(rules), "\n")

rules_tbl <- rules_to_tibble(rules)
saveRDS(rules_tbl, "data/clean/rules.rds")
saveRDS(item_freq, "data/clean/item_freq.rds")

cat("\n=== Top 10 rules by lift ===\n")
print(rules_tbl |> head(10), width = Inf)

# Sanity check against the engineered ground truth (simulated data only)
cat("\n=== Ground-truth check: pasta -> pasta_sauce ===\n")
print(check_known_rule(rules_tbl, "pasta", "pasta_sauce"))

cat("\n=== Ground-truth check: diapers -> beer ===\n")
print(check_known_rule(rules_tbl, "diapers", "beer"))
