# Reusable functions for market basket analysis using the apriori
# algorithm (via the `arules` package). This file is intentionally
# heavy on comments explaining WHY each step works the way it does,
# since the metrics (support/confidence/lift) are easy to compute but
# easy to misinterpret.

library(arules)
library(dplyr)
library(tibble)

#' Convert a long-format (transaction_id, item) data frame into an
#' arules "transactions" object -- the input format the apriori
#' algorithm requires (conceptually: a list of item sets, one per
#' basket, NOT a regular data frame).
#'
#' @param df A data frame with columns transaction_id and item.
#' @return An arules `transactions` S4 object.
to_transactions <- function(df) {
  split_list <- split(as.character(df$item), df$transaction_id)
  as(split_list, "transactions")
}

#' Run the apriori algorithm and return rules above given thresholds.
#'
#' @param trans An arules transactions object (from to_transactions()).
#' @param min_support Minimum support (see explanation in the report):
#'   how often the rule's items appear together, as a fraction of all
#'   transactions. Default 0.01 (1% of baskets).
#' @param min_confidence Minimum confidence: of baskets containing the
#'   LHS, what fraction also contain the RHS. Default 0.30 (30%).
#' @param min_lift Rules are additionally filtered to lift > 1 after
#'   mining, since lift <= 1 means the association is coincidental or
#'   negative (see report for why support/confidence alone can mislead).
#' @return An arules `rules` object.
run_apriori <- function(trans, min_support = 0.01, min_confidence = 0.3, min_lift = 1) {
  rules <- apriori(
    trans,
    parameter = list(
      supp    = min_support,
      conf    = min_confidence,
      minlen  = 2,     # at least 1 item on each side (lhs => rhs)
      target  = "rules"
    ),
    control = list(verbose = FALSE)
  )
  rules[quality(rules)$lift > min_lift]
}

#' Convert an arules rules object into a plain tibble, sorted by lift.
#' Much easier to work with in ggplot2/dplyr than the raw S4 object.
rules_to_tibble <- function(rules) {
  if (length(rules) == 0) {
    return(tibble(lhs = character(), rhs = character(), support = numeric(),
                  confidence = numeric(), lift = numeric(), count = integer()))
  }

  df <- as(rules, "data.frame") |> as_tibble()

  # arules formats rules as "{item1,item2} => {item3}" in one column;
  # split that into separate lhs/rhs text columns for readability.
  df |>
    tidyr::separate(rules, into = c("lhs", "rhs"), sep = " => ", remove = TRUE) |>
    mutate(
      lhs = gsub("[{}]", "", lhs),
      rhs = gsub("[{}]", "", rhs)
    ) |>
    arrange(desc(lift))
}

#' Check mined rules against a known "ground truth" association (only
#' meaningful for the simulated dataset, where we engineered specific
#' item pairs to co-occur). A real dataset has no ground truth to check
#' against -- this function exists purely to validate that the method
#' correctly recovers a KNOWN signal before trusting it on unknown data.
check_known_rule <- function(rules_tbl, trigger_item, boosted_item) {
  rules_tbl |>
    filter(grepl(trigger_item, lhs, fixed = TRUE), grepl(boosted_item, rhs, fixed = TRUE))
}
