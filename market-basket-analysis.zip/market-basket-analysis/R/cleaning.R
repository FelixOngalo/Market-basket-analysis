# Cleaning + reshaping for market basket analysis.
#
# arules (the package used for the apriori algorithm) expects a
# "transactions" object, which it can build from a long-format data
# frame of (transaction_id, item) pairs -- which is exactly the shape
# our simulated/raw data is already in. For a real retail dataset
# (e.g. Online Retail II), the long format is: one row per
# (invoice_no, product_description).

library(dplyr)
library(janitor)

clean_transactions_long <- function(raw) {
  raw |>
    clean_names() |>
    filter(!is.na(transaction_id), !is.na(item), item != "") |>
    distinct(transaction_id, item) |>     # a basket shouldn't count the same item twice
    mutate(item = as.factor(item))
}
