# Market Basket Analysis: What Gets Bought Together

**Question:** *(fill in)* Which products are frequently purchased together, and which of those associations are strong and common enough to act on (bundling, placement, cross-sell)?

**Key findings:** *(fill in after running; your top 2-3 rules with support/confidence/lift, and one concrete recommendation)*

**Tools:** R, `arules` (apriori algorithm), `arulesViz`, tidyverse, Quarto

## Why this project

This is a different analytical technique than anything else in the portfolio: **association rule mining**, the method behind "customers who bought X also bought Y." It's a classic retail analytics tool, and it comes with real interpretation traps (see "confidence alone is misleading" in the report) that are worth understanding precisely rather than just running `apriori()` and reporting whatever comes out.

## Reproduce

1. Get data: run `source("R/00_simulate_data.R")` for a ready-to-use simulated dataset with deliberately engineered item associations (clearly label results as illustrative if you keep this), **or** substitute the real Online Retail II dataset (see `R/00_get_data.R`).
2. `install.packages(c("arules", "arulesViz", "tidyverse", "janitor", "scales", "quarto"))`
3. Run in order:
   - `R/01_clean.R`
   - `R/02_mine_rules.R`
   - Render `reports/report.qmd`

## Method in brief

1. **Reshape to transactions:** each basket becomes a set of items (not a row of columns) — the format the `arules` package needs.
2. **Check item frequency first:** before mining rules, see which items are common or rare on their own — this context is essential for correctly reading the rules later.
3. **Mine rules with apriori:** the algorithm uses the *apriori principle* (an infrequent item set can't be part of a frequent larger one) to prune the search space, rather than checking every possible item combination.
4. **Filter on lift, not just confidence:** confidence alone is misleading when an item is simply popular overall — lift corrects for that by comparing a rule's confidence to the item's base rate.
5. **Validate against known structure:** the simulated dataset has specific associations built in; recovering them confirms the method works before trusting it on data where the answer isn't already known.
6. **Translate rules into action:** not every statistically valid rule is business-actionable — support and lift together determine whether a rule suggests a storewide change or a narrow, targeted one.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| Transaction / basket | One purchase event — the set of items bought together |
| Support | How often an item combination appears, as a share of all transactions |
| Confidence | Of baskets with the rule's left-hand items, the share that also have the right-hand item |
| Lift | How much more likely the right-hand item is, given the left-hand item, compared to its normal rate. Lift = 1 means no real association |
| Apriori principle | If a smaller item set is infrequent, no larger set containing it can be frequent — this is what makes the algorithm computationally feasible |
| Rule | A statement of the form {A, B} → {C}, scored by support, confidence, and lift |

## Project structure

```
R/00_get_data.R           real-data source notes
R/00_simulate_data.R      generates the default simulated transactions, with known associations
R/cleaning.R               cleaning/reshaping function
R/01_clean.R                run cleaning
R/basket_functions.R        apriori wrapper, rule formatting, ground-truth check (heavily commented)
R/02_mine_rules.R           run the algorithm, inspect top rules
reports/report.qmd          full write-up: method explanation, rules, validation, business recommendation
```

## Limitations

*(fill in — see the report's own Limitations section for a starting list: correlation vs causation, threshold sensitivity, simulated vs real data)*
